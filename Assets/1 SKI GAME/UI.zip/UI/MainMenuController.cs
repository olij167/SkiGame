using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using SkiGame.Progression;
using UnityEngine;
using UnityEngine.UIElements;

public sealed class MainMenuController : MonoBehaviour
{
    private enum ViewState
    {
        Home,
        Play,
        Settings
    }

    [Header("Scene Names")]
    [SerializeField] private string menuSceneName = "MainMenu";

    [Header("UI Toolkit")]
    [SerializeField] private UIDocument document;

    [Header("Background Loader")]
    [SerializeField] private MenuBackgroundLoader backgroundLoader;

    private const int SlotCount = GameSaveSystem.MaxSlots;

    private ViewState _state = ViewState.Home;
    private int _selectedSlot;
    private bool _muteSettingsCallbacks;

    // Root panels
    private VisualElement _panelHome;
    private VisualElement _panelPlay;
    private VisualElement _panelSettings;

    // Simple delete modal
    private VisualElement _modalDeleteConfirm;
    private Button _btnConfirmDelete;
    private Button _btnCancelDelete;

    // Home
    private Button _btnPlay;
    private Button _btnSettings;
    private Button _btnQuit;

    // Play
    private Button _btnBackFromPlay;
    private Button _btnPrimarySlotAction;
    private Button _btnDeleteSlot;

    private Label _playHeader;
    private Label _previewSlotName;
    private Label _previewSlotState;
    private Label _previewPlaythrough;
    private Label _previewCalendar;
    private Label _previewStats;

    // Settings
    private Button _btnBackFromSettings;
    private Button _btnResetSettings;
    private Button _btnSaveSettings;

    private Slider _sMaster;
    private Slider _sMusic;
    private Slider _sSfx;
    private Label _lblMaster;
    private Label _lblMusic;
    private Label _lblSfx;

    private DropdownField _ddQuality;
    private DropdownField _ddResolution;
    private DropdownField _ddWindowMode;

    private Slider _sFov;
    private Label _lblFov;

    private Slider _sUiScale;
    private Label _lblUiScale;
    private DropdownField _ddColourMode;

    private readonly List<Button> _slotButtons = new();

    private void Reset()
    {
        document = GetComponent<UIDocument>();
    }

    private void Awake()
    {
        if (document == null)
            document = GetComponent<UIDocument>();

        if (backgroundLoader == null)
            backgroundLoader = FindObjectOfType<MenuBackgroundLoader>();

        if (document == null)
        {
            Debug.LogError("[MainMenuController] Missing UIDocument.");
            enabled = false;
            return;
        }

        Bind(document.rootVisualElement);
        Wire();

        SetView(ViewState.Home);
        HideDeleteModal();
    }

    private void Start()
    {
        GameSettingsService.EnsureLoaded();
        RefreshSettingsUI(GameSettingsService.Current);

        _selectedSlot = Mathf.Clamp(GameSaveSystem.ActiveSlotId, 0, SlotCount - 1);

        RefreshSlotCards();
        RefreshSelectedSlotPreview();

        document.rootVisualElement.schedule.Execute(() =>
        {
            _btnPlay?.Focus();
        }).ExecuteLater(10);
    }

    private void OnEnable()
    {
        GameSettingsService.OnChanged += OnSettingsChanged;
    }

    private void OnDisable()
    {
        GameSettingsService.OnChanged -= OnSettingsChanged;
    }

    private void OnSettingsChanged(GameSettingsProfile profile)
    {
        RefreshSettingsUI(profile);
    }

    private void Bind(VisualElement root)
    {
        _panelHome = root.Q<VisualElement>("Panel_Home");
        _panelPlay = root.Q<VisualElement>("Panel_Play");
        _panelSettings = root.Q<VisualElement>("Panel_Settings");

        _modalDeleteConfirm = root.Q<VisualElement>("Modal_DeleteConfirm");
        _btnConfirmDelete = root.Q<Button>("Button_ConfirmDelete");
        _btnCancelDelete = root.Q<Button>("Button_CancelDelete");

        // Home
        _btnPlay = root.Q<Button>("Button_Play");
        _btnSettings = root.Q<Button>("Button_OpenSettings");
        _btnQuit = root.Q<Button>("Button_Quit");

        // Play
        _btnBackFromPlay = root.Q<Button>("Button_BackFromPlay");
        _btnPrimarySlotAction = root.Q<Button>("Button_PrimarySlotAction");
        _btnDeleteSlot = root.Q<Button>("Button_DeleteSlot");

        _playHeader = root.Q<Label>("Label_PlayHeader");
        _previewSlotName = root.Q<Label>("Label_PreviewSlotName");
        _previewSlotState = root.Q<Label>("Label_PreviewSlotState");
        _previewPlaythrough = root.Q<Label>("Label_PreviewPlaythrough");
        _previewCalendar = root.Q<Label>("Label_PreviewCalendar");
        _previewStats = root.Q<Label>("Label_PreviewStats");

        _slotButtons.Clear();
        for (int i = 0; i < SlotCount; i++)
        {
            var button = root.Q<Button>($"Button_Slot_{i}");
            if (button != null)
                _slotButtons.Add(button);
        }

        // Settings
        _btnBackFromSettings = root.Q<Button>("Button_BackFromSettings");
        _btnResetSettings = root.Q<Button>("Button_ResetSettings");
        _btnSaveSettings = root.Q<Button>("Button_SaveSettings");

        _sMaster = root.Q<Slider>("Slider_MasterVolume");
        _sMusic = root.Q<Slider>("Slider_MusicVolume");
        _sSfx = root.Q<Slider>("Slider_SfxVolume");
        _lblMaster = root.Q<Label>("Label_MasterVolume");
        _lblMusic = root.Q<Label>("Label_MusicVolume");
        _lblSfx = root.Q<Label>("Label_SfxVolume");

        _ddQuality = root.Q<DropdownField>("Dropdown_Quality");
        _ddResolution = root.Q<DropdownField>("Dropdown_Resolution");
        _ddWindowMode = root.Q<DropdownField>("Dropdown_WindowMode");

        _sFov = root.Q<Slider>("Slider_Fov");
        _lblFov = root.Q<Label>("Label_Fov");

        _sUiScale = root.Q<Slider>("Slider_UiScale");
        _lblUiScale = root.Q<Label>("Label_UiScale");
        _ddColourMode = root.Q<DropdownField>("Dropdown_ColorAccessibility");

        PopulateSettingsChoices();
    }

    private void Wire()
    {
        // Home
        if (_btnPlay != null)
        {
            _btnPlay.clicked += () =>
            {
                SetView(ViewState.Play);
                RefreshSlotCards();
                RefreshSelectedSlotPreview();
            };
        }

        if (_btnSettings != null)
        {
            _btnSettings.clicked += () =>
            {
                SetView(ViewState.Settings);
                RefreshSettingsUI(GameSettingsService.Current);
            };
        }

        if (_btnQuit != null)
        {
            _btnQuit.clicked += Quit;
        }

        // Play
        if (_btnBackFromPlay != null)
            _btnBackFromPlay.clicked += () => SetView(ViewState.Home);

        if (_btnPrimarySlotAction != null)
            _btnPrimarySlotAction.clicked += OnClickPrimarySlotAction;

        if (_btnDeleteSlot != null)
            _btnDeleteSlot.clicked += ShowDeleteModal;

        for (int i = 0; i < _slotButtons.Count; i++)
        {
            int slot = i;
            if (_slotButtons[i] != null)
                _slotButtons[i].clicked += () => SelectSlot(slot);
        }

        // Delete modal
        if (_btnConfirmDelete != null)
            _btnConfirmDelete.clicked += ConfirmDeleteSlot;

        if (_btnCancelDelete != null)
            _btnCancelDelete.clicked += HideDeleteModal;

        // Settings
        if (_btnBackFromSettings != null)
            _btnBackFromSettings.clicked += () => SetView(ViewState.Home);

        if (_btnResetSettings != null)
        {
            _btnResetSettings.clicked += () =>
            {
                GameSettingsService.ResetToDefaults();
                GameSettingsService.Save();
                RefreshSettingsUI(GameSettingsService.Current);
            };
        }

        if (_btnSaveSettings != null)
            _btnSaveSettings.clicked += () => GameSettingsService.Save();

        WireSettingsInputs();
    }

    private void SetView(ViewState state)
    {
        _state = state;

        SetVisible(_panelHome, state == ViewState.Home);
        SetVisible(_panelPlay, state == ViewState.Play);
        SetVisible(_panelSettings, state == ViewState.Settings);

        HideDeleteModal();
    }

    private static void SetVisible(VisualElement element, bool visible)
    {
        if (element == null) return;
        element.style.display = visible ? DisplayStyle.Flex : DisplayStyle.None;
    }

    private void ShowDeleteModal()
    {
        if (_modalDeleteConfirm == null) return;
        _modalDeleteConfirm.style.display = DisplayStyle.Flex;
    }

    private void HideDeleteModal()
    {
        if (_modalDeleteConfirm == null) return;
        _modalDeleteConfirm.style.display = DisplayStyle.None;
    }

    private void SelectSlot(int slot)
    {
        _selectedSlot = Mathf.Clamp(slot, 0, SlotCount - 1);
        GameSaveSystem.ActiveSlotId = _selectedSlot;

        RefreshSlotCards();
        RefreshSelectedSlotPreview();
    }

    private void RefreshSlotCards()
    {
        var manifest = GameSaveSystem.LoadOrCreateManifest();

        for (int i = 0; i < SlotCount; i++)
        {
            var button = document.rootVisualElement.Q<Button>($"Button_Slot_{i}");
            var title = document.rootVisualElement.Q<Label>($"Label_SlotTitle_{i}");
            var sub = document.rootVisualElement.Q<Label>($"Label_SlotSub_{i}");

            var meta = GameSaveSystem.GetSlotMeta(manifest, i);
            bool hasData = meta != null && meta.hasData;

            if (title != null)
                title.text = meta?.displayName ?? $"Save {i + 1}";

            if (sub != null)
                sub.text = hasData ? "Continue existing save" : "Start a new game";

            if (button != null)
            {
                button.EnableInClassList("slot-selected", i == _selectedSlot);
            }
        }

        if (_playHeader != null)
            _playHeader.text = $"Save Slot {_selectedSlot + 1}";
    }

    private void RefreshSelectedSlotPreview()
    {
        bool hasData = File.Exists(GameSaveSystem.GetProfilePath(_selectedSlot));

        if (_previewSlotName != null)
            _previewSlotName.text = $"Save {_selectedSlot + 1}";

        if (_previewSlotState != null)
            _previewSlotState.text = hasData ? "Existing career" : "Empty slot";

        if (!hasData)
        {
            if (_previewPlaythrough != null) _previewPlaythrough.text = "-";
            if (_previewCalendar != null) _previewCalendar.text = "-";
            if (_previewStats != null) _previewStats.text = "-";

            if (_btnPrimarySlotAction != null)
                _btnPrimarySlotAction.text = "New Game";

            if (_btnDeleteSlot != null)
                _btnDeleteSlot.SetEnabled(false);

            return;
        }

        if (TryLoadProfile(_selectedSlot, out var profile))
        {
            if (_previewPlaythrough != null)
            {
                int playthroughId = 0;
                if (profile.playthrough != null)
                    playthroughId = profile.playthrough.playthroughId;

                _previewPlaythrough.text = $"Playthrough {Mathf.Max(1, playthroughId + 1)}";
            }

            if (_previewCalendar != null)
                _previewCalendar.text = FormatCalendar(profile);

            if (_previewStats != null)
                _previewStats.text = FormatStats(profile);
        }
        else
        {
            if (_previewPlaythrough != null) _previewPlaythrough.text = "Unavailable";
            if (_previewCalendar != null) _previewCalendar.text = "Unavailable";
            if (_previewStats != null) _previewStats.text = "Unavailable";
        }

        if (_btnPrimarySlotAction != null)
            _btnPrimarySlotAction.text = "Continue";

        if (_btnDeleteSlot != null)
            _btnDeleteSlot.SetEnabled(true);
    }

    private void OnClickPrimarySlotAction()
    {
        bool hasData = File.Exists(GameSaveSystem.GetProfilePath(_selectedSlot));

        if (hasData)
        {
            GameStartBootstrap.RequestLoadGame(_selectedSlot);
        }
        else
        {
            GameStartBootstrap.RequestNewGame(_selectedSlot);
        }

        StartCoroutine(EnterGameRoutine());
    }

    private void ConfirmDeleteSlot()
    {
        HideDeleteModal();

        GameSaveSystem.DeleteSlot(_selectedSlot);
        RefreshSlotCards();
        RefreshSelectedSlotPreview();
    }

    private IEnumerator EnterGameRoutine()
    {
        if (backgroundLoader == null)
        {
            Debug.LogError("[MainMenuController] Missing MenuBackgroundLoader reference.");
            yield break;
        }

        yield return backgroundLoader.EnterGameplayAndUnloadMenu(menuSceneName);
    }

    public void Quit()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }

    private bool TryLoadProfile(int slotId, out PlayerStatsProfile profile)
    {
        profile = null;

        string path = GameSaveSystem.GetProfilePath(slotId);
        if (!File.Exists(path))
            return false;

        try
        {
            string json = File.ReadAllText(path);
            if (string.IsNullOrWhiteSpace(json))
                return false;

            profile = JsonUtility.FromJson<PlayerStatsProfile>(json);
            if (profile == null)
                return false;

            profile.Sanitize();
            return true;
        }
        catch
        {
            return false;
        }
    }

    private static string FormatCalendar(PlayerStatsProfile profile)
    {
        if (profile == null)
            return "-";

        int dayKey = profile.dailyTasks != null ? profile.dailyTasks.dayKey : -1;
        if (!TryParseDayKey(dayKey, out var currentDate))
            return "-";

        bool hasStart =
            profile.playthrough != null &&
            profile.playthrough.calendarStartYear > 0 &&
            profile.playthrough.calendarStartDayOfYear > 0;

        string datePart = currentDate.ToString("d MMM yyyy", CultureInfo.InvariantCulture);

        if (!hasStart)
            return datePart;

        var startDate = new DateTime(profile.playthrough.calendarStartYear, 1, 1, 0, 0, 0, DateTimeKind.Utc)
            .AddDays(profile.playthrough.calendarStartDayOfYear - 1);

        int daysSinceStart = Mathf.Max(0, (int)(currentDate.Date - startDate.Date).TotalDays);
        int week = (daysSinceStart / 7) + 1;
        int day = (daysSinceStart % 7) + 1;

        return $"Week {week}, Day {day}";
    }

    private static bool TryParseDayKey(int dayKey, out DateTime dateUtc)
    {
        dateUtc = default;

        if (dayKey <= 0)
            return false;

        string raw = dayKey.ToString(CultureInfo.InvariantCulture);
        if (raw.Length != 8)
            return false;

        return DateTime.TryParseExact(
            raw,
            "yyyyMMdd",
            CultureInfo.InvariantCulture,
            DateTimeStyles.AssumeUniversal | DateTimeStyles.AdjustToUniversal,
            out dateUtc
        );
    }

    private static string FormatStats(PlayerStatsProfile profile)
    {
        if (profile?.lifetime == null)
            return "-";

        int runs = profile.lifetime.totalRunsCompleted;
        float km = profile.lifetime.totalDistanceMeters / 1000f;
        float vert = profile.lifetime.totalVerticalDescentMeters;

        if (runs <= 0 && km <= 0.01f && vert <= 0.01f)
            return "-";

        return $"{runs} runs � {km:0.#} km � {vert:0} m vert";
    }

    // =========================================================
    // Settings
    // =========================================================

    private void PopulateSettingsChoices()
    {
        if (_ddQuality != null)
        {
            _ddQuality.choices = new List<string>(QualitySettings.names);
        }

        if (_ddWindowMode != null)
        {
            _ddWindowMode.choices = new List<string> { "Windowed", "Borderless", "Fullscreen" };
        }

        if (_ddResolution != null)
        {
            _ddResolution.choices = new List<string>();
            var resolutions = Screen.resolutions;

            if (resolutions != null && resolutions.Length > 0)
            {
                for (int i = 0; i < resolutions.Length; i++)
                {
#if UNITY_2022_2_OR_NEWER
                    int hz = Mathf.RoundToInt((float)resolutions[i].refreshRateRatio.value);
#else
                    int hz = resolutions[i].refreshRate;
#endif
                    _ddResolution.choices.Add($"{resolutions[i].width}x{resolutions[i].height} @ {hz}Hz");
                }
            }
            else
            {
                _ddResolution.choices.Add("Current");
            }
        }

        if (_ddColourMode != null)
        {
            _ddColourMode.choices = new List<string>
            {
                "None",
                "Protanopia",
                "Deuteranopia",
                "Tritanopia"
            };
        }
    }

    private void WireSettingsInputs()
    {
        if (_sMaster != null)
            _sMaster.RegisterValueChangedCallback(evt =>
            {
                if (_muteSettingsCallbacks) return;
                MutateSettings(p => p.masterVolume = evt.newValue);
            });

        if (_sMusic != null)
            _sMusic.RegisterValueChangedCallback(evt =>
            {
                if (_muteSettingsCallbacks) return;
                MutateSettings(p => p.musicVolume = evt.newValue);
            });

        if (_sSfx != null)
            _sSfx.RegisterValueChangedCallback(evt =>
            {
                if (_muteSettingsCallbacks) return;
                MutateSettings(p => p.sfxVolume = evt.newValue);
            });

        if (_ddQuality != null)
            _ddQuality.RegisterValueChangedCallback(evt =>
            {
                if (_muteSettingsCallbacks) return;
                int idx = _ddQuality.choices.IndexOf(evt.newValue);
                MutateSettings(p => p.qualityLevel = idx);
            });

        if (_ddWindowMode != null)
            _ddWindowMode.RegisterValueChangedCallback(evt =>
            {
                if (_muteSettingsCallbacks) return;

                int mode = evt.newValue switch
                {
                    "Windowed" => (int)FullScreenMode.Windowed,
                    "Borderless" => (int)FullScreenMode.FullScreenWindow,
                    "Fullscreen" => (int)FullScreenMode.ExclusiveFullScreen,
                    _ => (int)FullScreenMode.FullScreenWindow
                };

                MutateSettings(p => p.fullScreenMode = mode);
            });

        if (_ddResolution != null)
            _ddResolution.RegisterValueChangedCallback(evt =>
            {
                if (_muteSettingsCallbacks) return;

                int idx = _ddResolution.choices.IndexOf(evt.newValue);
                var resolutions = Screen.resolutions;

                if (resolutions == null || idx < 0 || idx >= resolutions.Length)
                    return;

                var res = resolutions[idx];
#if UNITY_2022_2_OR_NEWER
                int hz = Mathf.RoundToInt((float)res.refreshRateRatio.value);
#else
                int hz = res.refreshRate;
#endif

                MutateSettings(p =>
                {
                    p.resolutionWidth = res.width;
                    p.resolutionHeight = res.height;
                    p.resolutionRefreshHz = hz;
                });
            });

        if (_sFov != null)
            _sFov.RegisterValueChangedCallback(evt =>
            {
                if (_muteSettingsCallbacks) return;
                MutateSettings(p => p.cameraFov = evt.newValue);
            });

        if (_sUiScale != null)
            _sUiScale.RegisterValueChangedCallback(evt =>
            {
                if (_muteSettingsCallbacks) return;
                MutateSettings(p => p.uiScale = evt.newValue);
            });

        if (_ddColourMode != null)
            _ddColourMode.RegisterValueChangedCallback(evt =>
            {
                if (_muteSettingsCallbacks) return;
                int idx = Mathf.Max(0, _ddColourMode.choices.IndexOf(evt.newValue));
                MutateSettings(p => p.colorAccessibilityMode = idx);
            });
    }

    private void MutateSettings(Action<GameSettingsProfile> mutator)
    {
        var current = GameSettingsService.Current;
        var next = JsonUtility.FromJson<GameSettingsProfile>(JsonUtility.ToJson(current));

        mutator?.Invoke(next);
        next.Sanitize();

        GameSettingsService.Set(next, applyMinimal: true);
        GameSettingsService.Save();
    }

    private void RefreshSettingsUI(GameSettingsProfile profile)
    {
        if (profile == null)
            return;

        _muteSettingsCallbacks = true;

        if (_sMaster != null) _sMaster.SetValueWithoutNotify(profile.masterVolume);
        if (_sMusic != null) _sMusic.SetValueWithoutNotify(profile.musicVolume);
        if (_sSfx != null) _sSfx.SetValueWithoutNotify(profile.sfxVolume);

        if (_lblMaster != null) _lblMaster.text = $"{Mathf.RoundToInt(profile.masterVolume * 100f)}%";
        if (_lblMusic != null) _lblMusic.text = $"{Mathf.RoundToInt(profile.musicVolume * 100f)}%";
        if (_lblSfx != null) _lblSfx.text = $"{Mathf.RoundToInt(profile.sfxVolume * 100f)}%";

        if (_ddQuality != null && _ddQuality.choices.Count > 0)
        {
            int q = profile.qualityLevel;
            if (q < 0 || q >= _ddQuality.choices.Count)
                q = Mathf.Clamp(QualitySettings.GetQualityLevel(), 0, _ddQuality.choices.Count - 1);

            _ddQuality.SetValueWithoutNotify(_ddQuality.choices[q]);
        }

        if (_ddWindowMode != null)
        {
            string mode = ((FullScreenMode)profile.fullScreenMode) switch
            {
                FullScreenMode.Windowed => "Windowed",
                FullScreenMode.FullScreenWindow => "Borderless",
                FullScreenMode.ExclusiveFullScreen => "Fullscreen",
                _ => "Borderless"
            };

            if (_ddWindowMode.choices.Contains(mode))
                _ddWindowMode.SetValueWithoutNotify(mode);
        }

        if (_ddResolution != null && _ddResolution.choices.Count > 0)
        {
            string match = _ddResolution.choices[0];
            var resolutions = Screen.resolutions;

            if (resolutions != null && resolutions.Length > 0 &&
                profile.resolutionWidth > 0 && profile.resolutionHeight > 0)
            {
                for (int i = 0; i < resolutions.Length; i++)
                {
#if UNITY_2022_2_OR_NEWER
                    int hz = Mathf.RoundToInt((float)resolutions[i].refreshRateRatio.value);
#else
                    int hz = resolutions[i].refreshRate;
#endif
                    if (resolutions[i].width == profile.resolutionWidth &&
                        resolutions[i].height == profile.resolutionHeight &&
                        (profile.resolutionRefreshHz <= 0 || hz == profile.resolutionRefreshHz))
                    {
                        match = $"{resolutions[i].width}x{resolutions[i].height} @ {hz}Hz";
                        break;
                    }
                }
            }

            if (_ddResolution.choices.Contains(match))
                _ddResolution.SetValueWithoutNotify(match);
        }

        if (_sFov != null) _sFov.SetValueWithoutNotify(profile.cameraFov);
        if (_lblFov != null) _lblFov.text = $"{Mathf.RoundToInt(profile.cameraFov)}";

        if (_sUiScale != null) _sUiScale.SetValueWithoutNotify(profile.uiScale);
        if (_lblUiScale != null) _lblUiScale.text = $"{Mathf.RoundToInt(profile.uiScale * 100f)}%";

        if (_ddColourMode != null && _ddColourMode.choices.Count > 0)
        {
            int idx = Mathf.Clamp(profile.colorAccessibilityMode, 0, _ddColourMode.choices.Count - 1);
            _ddColourMode.SetValueWithoutNotify(_ddColourMode.choices[idx]);
        }

        _muteSettingsCallbacks = false;
    }
}