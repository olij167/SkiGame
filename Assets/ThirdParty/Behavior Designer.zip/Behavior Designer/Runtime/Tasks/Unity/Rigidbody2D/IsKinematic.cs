using UnityEngine;

namespace BehaviorDesigner.Runtime.Tasks.Unity.UnityRigidbody2D
{
    [TaskCategory("Unity/Rigidbody2D")]
    [TaskDescription("Returns Success if the Rigidbody2D is kinematic, otherwise Failure.")]
    public class IsKinematic : Conditional
    {
        [Tooltip("The GameObject that the task operates on. If null the task GameObject is used.")]
        public SharedGameObject targetGameObject;

        private Rigidbody2D rigidbody2D;
        private GameObject prevGameObject;

        public override void OnStart()
        {
            var currentGameObject = GetDefaultGameObject(targetGameObject.Value);
            if (currentGameObject != prevGameObject) {
                rigidbody2D = currentGameObject.GetComponent<Rigidbody2D>();
                prevGameObject = currentGameObject;
            }
        }

        public override TaskStatus OnUpdate()
        {
            if (rigidbody2D == null) {
                Debug.LogWarning("Rigidbody2D is null");
                return TaskStatus.Failure;
            }
#if UNITY_6000_0_OR_NEWER
            return rigidbody2D.bodyType == RigidbodyType2D.Kinematic ? TaskStatus.Success : TaskStatus.Failure;
#else
            return rigidbody2D.isKinematic ? TaskStatus.Success : TaskStatus.Failure;
#endif
        }

        public override void OnReset()
        {
            targetGameObject = null;
        }
    }
}
