﻿using UnityEditor;

namespace RaycastPro.Planers
{
    using RaySensors;
    using UnityEngine;

    [AddComponentMenu("RaycastPro/Planers/" + nameof(ReflectPlanar))]
    public sealed class ReflectPlanar : Planar
    {
        public override void GetForward(RaySensor raySensor, out Vector3 forward)
        {
            switch (baseDirection)
            {
                case DirectionOutput.NegativeHitNormal: forward = -raySensor.hit.normal; return;
                case DirectionOutput.HitDirection: forward = raySensor.HitDirection; return;
                case DirectionOutput.SensorLocal: forward = raySensor.LocalDirection.normalized; return;
            }
            forward = transform.forward;
        }
        
#if UNITY_EDITOR
        internal override string Info => "A reflective planar modifier for the 'Planar Sensitive' ray system. Upon contact, it calculates a new direction based on the Law of Reflection, simulating a mirror-like surface. The resulting reflected ray is then emitted from the point of impact, continuing the path's propagation with its new trajectory."
                                         +HDependent+HAccurate;
        internal override void OnGizmos() => DrawPlanar();
        internal override void EditorPanel(SerializedObject _so, bool hasMain = true, bool hasGeneral = true,
            bool hasEvents = true,
            bool hasInfo = true)
        {
            if (hasGeneral) GeneralField(_so);

            if (hasEvents) EventField(_so);
        }
#endif
        
        private Vector3 forward, look;
        private RaySensor clone;

        internal override void OnReceiveRay(RaySensor sensor)
        {
            clone = sensor.cloneRaySensor;
            if (!clone) return;
            if (clone.liner) clone.liner.enabled = sensor.liner.enabled;
            
            GetForward(sensor, out forward);
            clone.transform.forward = Vector3.Reflect(sensor.TipDirection, forward).normalized;
            clone.transform.position = sensor.hit.point - forward * offset;
            ApplyLengthControl(sensor);
        }
    }
}