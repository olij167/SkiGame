﻿namespace RaycastPro.Bullets
{
    using Bullets2D;
    using UnityEngine;

#if UNITY_EDITOR
    using UnityEditor;
#endif

    [AddComponentMenu("RaycastPro/Bullets/" + nameof(InstantBullet2D))]
    public sealed class InstantBullet2D : Bullet2D
    {
        internal override void RuntimeUpdate() => UpdateLifeProcess(GetDelta(timeMode));

        protected override void OnCast()
        {
            if (collisionRay.planarSensitive)
            {
                var clone = raySource.LastClone;
                transform.position = clone.TipTarget;
                // Hit Direction cuz don't want to place on hit Normal
                transform.right = clone.HitDirection.normalized;
                if (raySource.hit) InvokeDamageEvent(raySource.hit.transform);
            }
            else
            {
                transform.position = raySource.TipTarget;
                transform.right = raySource.HitDirection.normalized;
                if (raySource.hit) InvokeDamageEvent(raySource.hit.transform);
            }
        }
#if UNITY_EDITOR
        internal override string Info => "An impact effect spawner that is instantiated directly at a ray sensor's point of collision. Instead of traveling, it appears instantly upon a successful hit, aligning its orientation with the surface normal of the impact point. It features an option to parent itself to the hit object, making it ideal for creating persistent visual effects like bullet holes, scorch marks, or embedded projectiles. The component immediately invokes a damage event upon instantiation."
                                         + HDependent;

        internal override void EditorPanel(SerializedObject _so, bool hasMain = true, bool hasGeneral = true,
            bool hasEvents = true,
            bool hasInfo = true)
        {
            if (hasMain) { }
            if (hasGeneral) GeneralField(_so);

            if (hasEvents) EventField(_so);

            if (hasInfo) InformationField();
        }
#endif
    }
}
